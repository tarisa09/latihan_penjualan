<?php

namespace Database\Seeders;
use App\Models\kategori;

use Illuminate\Database\Seeder;

class kategoriTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        kategori::create([
            'nama' => 'Makanan'
            ]);
            kategori::create([
                'nama' => 'Perlengkapan Rumah Tangga'
            ]);
            kategori::create([
            'nama' => 'Alat Belajar'
            ]);
    }
}
